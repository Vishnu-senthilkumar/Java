public class rect
{
    public static void main(String args[])
    {
        area();
    }
    public static void area()
    {
        int l=10, b=5;
        int a = l*b;
        System.out.println(a);
    }
}