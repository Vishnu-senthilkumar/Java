interface one
{
    void play();
}
public class two implements one
{
    public void play()
    {
        System.out.print(3*5);
    }
}
public class three implements one
{
    public void play()
    {
        System.ot.print(6/3);
    }
    public static void main(String args[]);
    three O =new three
    O.play();

}