public class rec
{
    public static void main(String args[])
    {
        rec O=new rec();
        O.name();
    }
    public void name()
    {
        System.out.println("RIT");
    }
}