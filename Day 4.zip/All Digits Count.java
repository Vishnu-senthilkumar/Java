class UserMainCode {
    public int allDigitsCount(int input1) {
        return String.valueOf(input1).length();
    }
}
